package com.shiva.keycloakspi.initiate_auth;

import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.services.resource.RealmResourceProviderFactory;

public class CustomEndpointResourceProviderFactory implements RealmResourceProviderFactory {

    public static final String ID = "authentication";

    @Override
    public RealmResourceProvider create(KeycloakSession session) {
        return new CustomEndpointResource(session);
    }

    @Override
    public void init(org.keycloak.Config.Scope config) {
        // Implement if needed
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
        // Implement if needed
    }

    @Override
    public void close() {
        // Implement if needed
    }

    @Override
    public String getId() {
        return ID;
    }
}
