package com.shiva.keycloakspi.initiate_auth;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.jboss.logging.Logger;
import org.keycloak.models.KeycloakSession;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.broker.provider.util.SimpleHttp;

public class CustomEndpointResource implements RealmResourceProvider {

    private static final Logger logger = Logger.getLogger(CustomEndpointResource.class);

    private final KeycloakSession session;

    public CustomEndpointResource(KeycloakSession session) {
        this.session = session;
    }

    @GET
    @Path("init")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCustomEndpoint(@QueryParam("response_type") String response_type,
                                      @QueryParam("client_id") String client_id,
                                      @QueryParam("state") String state,
                                      @QueryParam("scope") String scope,
                                      @QueryParam("redirect_uri") String redirect_uri,
                                      @QueryParam("code_challenge") String code_challenge,
                                      @QueryParam("code_challenge_method") String code_challenge_method,
                                      @QueryParam("response_mode") String response_mode) {
        try {
            // Build the URL with query parameters
            String url = String.format("http://localhost:8080/realms/htc/protocol/openid-connect/auth?" +
                            "response_type=%s&client_id=%s&state=%s&scope=%s&redirect_uri=%s" +
                            "&code_challenge=%s&code_challenge_method=%s&response_mode=%s",
                    response_type, client_id, state, scope, redirect_uri, code_challenge,
                    code_challenge_method, response_mode);

            // Create and send the request using Keycloak's SimpleHttp
            SimpleHttp.Response httpResponse = SimpleHttp
                    .doGet(url, session)
                    .asResponse();

            // Get the response as a string
            String responseString = httpResponse.asString();

            // Use regex to extract the action URL
            String actionUrl = extractActionUrlUsingRegex(responseString);

            if (actionUrl == null) {
                logger.error("Failed to find the action URL in the response.");
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Failed to find action URL").build();
            }

            // Log the action URL
            logger.infof("Extracted Action URL: %s", actionUrl);

            // Get the Set-Cookie headers
            List<String> setCookieHeaders = httpResponse.getHeader("Set-Cookie");

            String tmp= setCookieHeaders.stream()
                    .flatMap(header -> Stream.of(header.split(", "))) // Split on comma and space
                    .map(cookie -> cookie.split(";")[0]) // Take the part before the first ';'
                    .collect(Collectors.joining("; ")); // Join with '; '

            // Create a response builder
            String cleanedUrl = actionUrl.replace("&amp;", "&");
            Response.ResponseBuilder responseBuilder = Response.ok("done")
                    .header("X-Action-URL", cleanedUrl)
                    .header("cookie",tmp);

            // Process each Set-Cookie header
            for (String setCookieHeader : setCookieHeaders) {
                NewCookie cookie = parseSetCookieHeader(setCookieHeader);
                responseBuilder.cookie(cookie);
            }

            // Return the response without directly sending Set-Cookie headers
            return responseBuilder.build();

        } catch (Exception e) {
            logger.error("Error occurred while sending the request or processing the response", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Failed to send request").build();
        }
    }
    @POST
    @Path("authenticate")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticateUser(@FormParam("username") String username,
                                     @FormParam("password") String password,
                                     @FormParam("X-Action-URL") String x_Action_url,
                                     @HeaderParam("cookie") NewCookie cookie) {
        try {
            // Log the received x_Action_url
            logger.infof("Received X-Action-URL (encoded): %s", x_Action_url);
            // Create a new request with credentials and cookies
            SimpleHttp.Response httpResponse = SimpleHttp
                    .doPost(x_Action_url, session)
                    .param("username", username)
                    .param("password", password)
                    .header("Cookie", String.valueOf((cookie)))
                    .asResponse();
            logger.info("Request sent successfully");

            // Get the response as a string
            String responseString = httpResponse.asString();
            String responseStatus = String.valueOf(httpResponse.getStatus());
            String responseHeader = String.valueOf(httpResponse.getHeader("Location"));


            // Log the response
            logger.infof("Authentication response: %s", responseString);
            logger.infof("Authentication status response: %s", responseStatus);
            logger.infof("Authentication Location : %s", responseHeader);


            if (!responseStatus.equals("302")) {
                return Response.status(403).build();
            } else {
                return Response.ok(responseHeader).build();            }

        } catch (Exception e) {
            logger.error("Error occurred while authenticating the user: ", e);
            return Response.serverError().entity("Authentication failed").build();
        }
    }


    private String extractActionUrlUsingRegex(String html) {
        Pattern pattern = Pattern.compile("<form[^>]*id=\"kc-form-login\"[^>]*action=\"([^\"]*)\"");
        Matcher matcher = pattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private NewCookie parseSetCookieHeader(String setCookieHeader) {
        // Extract the cookie name and value from the Set-Cookie header
        String[] parts = setCookieHeader.split(";");
        String[] nameValue = parts[0].split("=", 2);
        if (nameValue.length != 2) {
            throw new IllegalArgumentException("Invalid Set-Cookie header format");
        }
        String name = nameValue[0].trim();
        String value = nameValue[1].trim();

        // Return a NewCookie object with basic attributes
        return new NewCookie(name, value, "/", null, null, NewCookie.DEFAULT_MAX_AGE, false);
    }

    @Override
    public Object getResource() {
        return this;
    }

    @Override
    public void close() {
        // Implement if needed
    }
}
